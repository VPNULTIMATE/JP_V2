<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.herokuapp.com?font=Poetsen+One&size=25&pause=1000&color=F70000&background=000000&center=true&vCenter=true&random=true&width=435&lines=FAN+VPN+REAKER" alt="Typing SVG" /></a>

<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.herokuapp.com?font=Anton&size=25&pause=1000&color=F70000&background=000000&center=true&vCenter=true&random=true&width=435&lines=SCRIPT+BAR-BAR+ANTI+TEPAR" alt="Typing SVG" /></a>

Auto Script Install All VPN Service By FanVpn
<img src="https://img.shields.io/badge/Version-1.0.0-blue.svg"></h2>

</p> 
<h2 align="center"> Supported Linux Distribution</h2>
<p align="center"><img src="https://d33wubrfki0l68.cloudfront.net/5911c43be3b1da526ed609e9c55783d9d0f6b066/9858b/assets/img/debian-ubuntu-hover.png"></p> 

### TESTED ON OS 
- UBUNTU 20.04 22 24.04 24.10
- DEBIAN 10 11 12

### FILTUR 🔥
![alt text](https://github.com/Pemulaajiw/permission/blob/main/install.jpg?raw=true) 
Silakan Yang mau edit script nya silakan😀.

## Sewa Autoscript
```html
1 Bulan 1 IP  : 8.000
1 Bulan 2 IP  : 15.000
2 Bulan 2 IP  : 25.000
4 Bulan 2 IP  : 40.000
Lifetime 2 IP : 70.000
Lifetime 5 IP : 100.000
```
# free add ip ke domain < off proxies>
https://sub.irawancandra2303.workers.dev/
## UPGRADE FOR OS
```
echo -e "net.ipv6.conf.all.disable_ipv6 = 1\nnet.ipv6.conf.default.disable_ipv6 = 1\nnet.ipv6.conf.lo.disable_ipv6 = 1" >> /etc/sysctl.conf && sysctl -p
```

```
apt update -y && apt upgrade -y --fix-missing && apt install curl jq wget screen build-essential -y && update-grub && apt dist-upgrade -y && sleep 2 && reboot
```
## INSTALL SCRIPT 
Masukkan perintah dibawah untuk menginstall Autoscript Premium
```
screen -S fnstvt-session bash -c "wget --inet4-only --no-check-certificate -O setup7.sh https://raw.githubusercontent.com/Pemulaajiw/script/main/setup7.sh && chmod +x setup7.sh && ./setup7.sh; read -p 'Tekan enter untuk keluar...'"
```
## MELANJUTKAN STUCK KETIKA INSTALL DIAWAL
```
screen -r -d apt install dos2unix && dos2unix fnstvt && bash fnstvt
```
==========================================================================================


  
## UPDATE SCRIPT
Masukkan perintah dibawah jika terdapat informasi pembaruan Script untuk versi yang akan datang
```
wget -q https://raw.githubusercontent.com/Pemulaajiw/script/main/update.sh && bash update.sh
```

## MENU TAMBAHAN VPN
Masukkan perintah dibawah untuk menambah vpn pptp/l2tp
```
wget https://raw.githubusercontent.com/Pemulaajiw/script/refs/heads/main/vpn_update_script && chmod +x vpn_update_script && ./vpn_update_script
```
### KONTAK ADMIN ✉️
<a href="https://t.me/AJW29" target=”_blank”><img src="https://img.shields.io/static/v1?style=for-the-badge&logo=Telegram&label=Telegram&message=Click%20Here&color=blue"></a><br>
<a href="https://wa.me/6287812264674" target=”_blank”><img src="https://img.shields.io/static/v1?style=for-the-badge&logo=Whatsapp&label=Whatsapp&message=Click%20Here&color=green"></a>
