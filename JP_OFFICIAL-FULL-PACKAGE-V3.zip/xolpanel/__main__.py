# ================================================
#  JP OFFICIAL — Managed Installer/Panel
#  Telegram: t.me/JPOFFICIALSTORE | WhatsApp: 087873951705
#  Revo: https://github.com/VPNULTIMATE/JP_V2/tree/main
#  Updated: 2025-12-15
# ================================================
from xolpanel import *
from importlib import import_module
from xolpanel.modules import ALL_MODULES
for module_name in ALL_MODULES:
 imported_module = import_module("xolpanel.modules." + module_name)
bot.run_until_disconnected()

