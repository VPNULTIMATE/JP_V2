# ================================================
#  JP OFFICIAL — Managed Installer/Panel
#  Telegram: t.me/JPOFFICIALSTORE | WhatsApp: 087873951705
#  Revo: https://github.com/VPNULTIMATE/JP_V2/tree/main
#  Updated: 2025-12-15
# ================================================
from xolpanel import *

@JP_OFFICIAL.on(events.NewMessage(pattern="/start"))
async def start(event):
	await event.reply("@JP_OFFICIAL")
