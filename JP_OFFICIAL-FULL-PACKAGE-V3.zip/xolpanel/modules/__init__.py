# ================================================
#  JP OFFICIAL — Managed Installer/Panel
#  Telegram: t.me/JPOFFICIALSTORE | WhatsApp: 087873951705
#  Revo: https://github.com/VPNULTIMATE/JP_V2/tree/main
#  Updated: 2025-12-15
# ================================================
import sys


def __list_all_modules():
 import glob
 from os.path import basename, dirname, isfile

 mod_paths = glob.glob(dirname(__file__) + "/*.py")
 all_modules = [
 basename(f)[:-3]
 for f in mod_paths
 if isfile(f) and f.endswith(".py") and not f.endswith("__init__.py")
 ]
 return all_modules
ALL_MODULES = sorted(__list_all_modules())
