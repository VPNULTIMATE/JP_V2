#!/bin/bash
# ================================================
#  JP OFFICIAL — Managed Installer/Panel
#  Telegram: t.me/JPOFFICIALSTORE | WhatsApp: 087873951705
#  Revo: https://github.com/VPNULTIMATE/JP_V2/tree/main
#  Updated: 2025-12-15
# ================================================
SCRIPT_NAME="fix.sh"
SCRIPT_VERSION="${SCRIPT_VERSION:-1.3.0}"
UPDATE_BASE_URL="${UPDATE_BASE_URL:-https://example.com/jp-official/installer}"
if [[ -f "$(dirname "$0")/self_update.inc.sh" ]]; then
 # shellcheck disable=SC1091
 source "$(dirname "$0")/self_update.inc.sh"
 self_update_check_and_apply "$SCRIPT_NAME" "$SCRIPT_VERSION" "$UPDATE_BASE_URL" "$@"
else
 echo "NOTE: self_update.inc.sh not found; continuing without self-update."
fi

# ================================================
# JP OFFICIAL VPN Installer
# Revo : https://github.com/VPNULTIMATE/JP_V2/tree/main
# Telegram: t.me/JPOFFICIALSTORE
# WA : 087873951705
# ================================================
apt-get install dropbear -y >/dev/null 2>&1
wget -q -O /etc/default/dropbear "https://raw.githubusercontent.com/bowowiwendi/JP OFFICIALVpn/ABSTRAK/cfg_conf_js/dropbear.conf"
chmod +x /etc/default/dropbear
/etc/init.d/dropbear restart
/etc/init.d/dropbear status