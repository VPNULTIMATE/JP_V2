#!/bin/bash
# ================================================
#  JP OFFICIAL — Managed Installer/Panel
#  Telegram: t.me/JPOFFICIALSTORE | WhatsApp: 087873951705
#  Revo: https://github.com/VPNULTIMATE/JP_V2/tree/main
#  Updated: 2025-12-15
# ================================================
function send_log(){
 # Bot pertama
 CHATID=$(grep -E "^#bot# " "/etc/bot/.bot.db" | cut -d ' ' -f 3)
 KEY=$(grep -E "^#bot# " "/etc/bot/.bot.db" | cut -d ' ' -f 2)
 TEXT="
◇━━━━━━━━━━━━━━━━━◇
 🔗GENERATE LINK BACKUP🔗
◇━━━━━━━━━━━━━━━━━◇
LINK BACKUP : $fix
◇━━━━━━━━━━━━━━━━━◇
"
 # Kirim ke bot pertama
 URL="https://api.telegram.org/bot$KEY/sendMessage"
 curl -s -X POST $URL --data-urlencode "chat_id=$CHATID" --data-urlencode "text=$TEXT" >/dev/null
}
clear
read -p "IP-YYYY-MM-DD : " iptanggal
url=$(rclone link del:backup/WT-${iptanggal}.zip) 
id=(`echo $url | grep '^https' | cut -d'=' -f2`)
link="https://drive.google.com/u/4/uc?id=${id}&export=download"
fix=$(jq -nr --arg msg "$link" '$msg')
clear
send_log
echo -e "$link"