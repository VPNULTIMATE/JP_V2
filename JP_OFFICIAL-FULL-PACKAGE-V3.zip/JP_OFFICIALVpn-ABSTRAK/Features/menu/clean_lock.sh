#!/bin/bash
# ================================================
#  JP OFFICIAL — Managed Installer/Panel
#  Telegram: t.me/JPOFFICIALSTORE | WhatsApp: 087873951705
#  Revo: https://github.com/VPNULTIMATE/JP_V2/tree/main
#  Updated: 2025-12-15
# ================================================

# File target
LOCK_FILE="/etc/xray/.lock.db"

# Hapus file jika ada
if [ -f "$LOCK_FILE" ]; then
 rm -f "$LOCK_FILE"
 echo "[$(date)] File $LOCK_FILE dihapus."
fi

# Buat file baru dengan konten yang ditentukan
cat > "$LOCK_FILE" <<EOF
#vmess
#vless
#trojan
#ss
EOF

echo "[$(date)] File $LOCK_FILE telah direset."