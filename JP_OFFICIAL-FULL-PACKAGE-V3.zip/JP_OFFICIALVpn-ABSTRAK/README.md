
# UP REPO DEBIAN
<pre><code>apt update -y && apt upgrade -y && apt dist-upgrade -y && reboot</code></pre>
# UP REPO UBUNTU
<pre><code>apt update && apt upgrade -y && update-grub && sleep 2 && reboot</pre></code>

### INSTALL SCRIPT 
<pre><code>sysctl -w net.ipv6.conf.all.disable_ipv6=1 && sysctl -w net.ipv6.conf.default.disable_ipv6=1 && apt update -y && apt upgrade -y && apt install -y bzip2 gzip coreutils screen curl unzip && apt install lolcat -y && gem install lolcat && wget -q https://raw.githubusercontent.com/bowowiwendi/JP OFFICIALVpn/ABSTRAK/setup-main.sh && chmod +x setup-main.sh && sed -i -e 's/\r$//' setup-main.sh && screen -S setupku ./setup-main.sh</code></pre>

### PERINTAH UPDATE 
<pre><code>wget https://raw.githubusercontent.com/bowowiwendi/JP OFFICIALVpn/ABSTRAK/files/update.sh && chmod +x update.sh && ./update.sh</code></pre>

### BOT DO
<pre><code>wget https://raw.githubusercontent.com/bowowiwendi/JP OFFICIALVpn/refs/heads/ABSTRAK/bot/install.sh && chmod +x install.sh && ./install.sh</code></pre>

### SLOW DNS
<pre><code>wget https://raw.githubusercontent.com/VPNULTIMATE/JP_V2/main/slowdns/install-sldns && chmod +x install-sldns && ./install-sldns</code></pre>

### TESTED ON OS 
- UBUNTU 20
- DEBIAN 10 ( Recomended )

### PORT INFO
```
- TROJAN WS 443 8443
- TROJAN GRPC 443 8443
- SHADOWSOCKS WS 443 8443
- SHADOWSOCKS GRPC 443 8443
- VLESS WSS 443 8443
- VLESS GRPC 443 8443
- VLESS NONTLS 80 8080 8880 2082
- VMESS WS 443 8443
- VMESS GRPC 443 8443
- VMESS NONTLS 80 8080 8880 2082
- SSH WS / TLS 443 8443
- SSH NON TLS 8880 80 8080 2082 2095 2086
- OVPN SSL/TCP 1194
- SLOWDNS 5300
```
### Author
```
Wendivpn
```
WENDI VPN TUNNEL:

<a href="https://t.me/WendiVpn" target=”_blank”><img src="https://img.shields.io/static/v1?style=for-the-badge&logo=Telegram&label=Telegram&message=Click%20Here&color=blue"></a><br>
```
WA: 083153170199
```
```
TELE: @JP_OFFICIAL
```
