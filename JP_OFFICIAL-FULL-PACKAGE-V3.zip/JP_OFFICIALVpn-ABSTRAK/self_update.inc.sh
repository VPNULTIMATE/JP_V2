#!/usr/bin/env bash
# ================================================
#  JP OFFICIAL — Managed Installer/Panel
#  Telegram: t.me/JPOFFICIALSTORE | WhatsApp: 087873951705
#  Revo: https://github.com/VPNULTIMATE/JP_V2/tree/main
#  Updated: 2025-12-15
# ================================================
set -euo pipefail
have_cmd() { command -v "$1" >/dev/null 2>&1; }
_fetch() {
 local url="$1"; shift || true
 local out="${1:-}"
 if have_cmd curl; then
 if [[ -n "$out" ]]; then curl -fsSL "$url" -o "$out"; else curl -fsSL "$url"; fi
 elif have_cmd wget; then
 if [[ -n "$out" ]]; then wget -qO "$out" "$url"; else wget -qO- "$url"; fi
 else
 echo "ERROR: curl/wget not found; cannot check for updates." >&2; return 127
 fi
}
_semver_lt() { local a="$1" b="$2"; [[ "$(printf '%s\n%s\n' "$a" "$b" | sort -V | head -n1)" != "$b" ]]; }
_verify_sha256() {
 local file="$1" exp="$2" got=""
 if command -v sha256sum >/dev/null 2>&1; then got="$(sha256sum "$file" | awk '{print $1}')"
 elif command -v shasum >/dev/null 2>&1; then got="$(shasum -a 256 "$file" | awk '{print $1}')"
 else echo "WARN: sha256 tool not found; skipping checksum verification." >&2; return 0; fi
 [[ "$got" == "$exp" ]] || { echo "ERROR: checksum mismatch for $file" >&2; return 1; }
}
self_update_check_and_apply() {
 local script_name="${1:-}" local_ver="${2:-}" base_url="${3:-}"
 [[ -z "$script_name" || -z "$local_ver" || -z "$base_url" ]] && return 0
 [[ "${NO_SELF_UPDATE:-0}" == "1" ]] && return 0
 local remote_ver; if ! remote_ver="$(_fetch "$base_url/VERSION")"; then
 echo "WARN: cannot fetch remote VERSION; continuing with local v$local_ver" >&2; return 0; fi
 remote_ver="$(echo "$remote_ver" | tr -d ' \t\r\n')"; [[ -z "$remote_ver" ]] && return 0
 if ! _semver_lt "$local_ver" "$remote_ver"; then echo "Installer up-to-date (v$local_ver)"; return 0; fi
 echo "Updating: local v$local_ver -> remote v$remote_ver"
 local tmp_dir; tmp_dir="$(mktemp -d)"; trap 'rm -rf "$tmp_dir"' EXIT
 local new_script="$tmp_dir/$script_name" sha_url="$base_url/$script_name.sha256" bin_url="$base_url/$script_name"
 _fetch "$bin_url" "$new_script" || { echo "ERROR: failed to download new installer." >&2; return 1; }
 chmod +x "$new_script"
 if _fetch "$sha_url" "$tmp_dir/sha256.txt"; then
 local expected; expected="$(awk '{print $1}' "$tmp_dir/sha256.txt" | tr -d '\r\n')"
 [[ -n "$expected" ]] && _verify_sha256 "$new_script" "$expected"
 fi
 local current_path="$0"
 if [[ ! -w "$current_path" ]]; then
 local dir; dir="$(dirname "$current_path")"; cp -f "$new_script" "$dir/$script_name"; chmod +x "$dir/$script_name"; exec "$dir/$script_name" "$@"
 else
 cp -f "$new_script" "$current_path"; chmod +x "$current_path"; exec "$current_path" "$@"
 fi
}
